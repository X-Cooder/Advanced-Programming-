﻿using System.Collections.Generic;

namespace YourProject.Models
{
    public class Class
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";

        // One-to-One / One-to-Many with Teacher
        public int? TeacherId { get; set; }
        public Teacher? Teacher { get; set; }

        // Many-to-Many with Students
        public ICollection<Student> Students { get; set; } = new List<Student>();

        public override string ToString() =>
            $"Class {Id}: {Name}, Teacher: {(Teacher != null ? Teacher.FirstName + " " + Teacher.LastName : "None")}";
    }
}
