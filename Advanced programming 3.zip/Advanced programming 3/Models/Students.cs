﻿using System.Collections.Generic;

namespace YourProject.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";

        // Many-to-Many with Classes
        public ICollection<Class> Classes { get; set; } = new List<Class>();

        public override string ToString() => $"Student {Id}: {FirstName} {LastName}";
    }
}
