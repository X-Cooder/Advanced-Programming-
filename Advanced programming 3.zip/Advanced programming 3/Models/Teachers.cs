﻿using System.Collections.Generic;

namespace YourProject.Models
{
    public class Teacher
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";

        // One-to-Many with Classes
        public ICollection<Class> Classes { get; set; } = new List<Class>();

        public override string ToString() => $"Teacher {Id}: {FirstName} {LastName}";
    }
}
