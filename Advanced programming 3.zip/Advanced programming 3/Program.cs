﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

#region Entities
public class Student
{
    public int Id { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";

    // Many-to-Many with Classes
    public ICollection<Class> Classes { get; set; } = new List<Class>();

    public override string ToString() => $"Student {Id}: {FirstName} {LastName}";
}

public class Class
{
    public int Id { get; set; }
    public string Name { get; set; } = "";

    // One-to-One with Teacher
    public int? TeacherId { get; set; }
    public Teacher? Teacher { get; set; }

    // Many-to-Many with Students
    public ICollection<Student> Students { get; set; } = new List<Student>();

    public override string ToString() =>
        $"Class {Id}: {Name}, Teacher: {(Teacher != null ? Teacher.FirstName + " " + Teacher.LastName : "None")}";
}

public class Teacher
{
    public int Id { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";

    // One-to-Many with Classes
    public ICollection<Class> Classes { get; set; } = new List<Class>();

    public override string ToString() => $"Teacher {Id}: {FirstName} {LastName}";
}
#endregion

#region DbContext
public class MyDatabaseContext : DbContext
{
    public string DbPath { get; }

    public DbSet<Student> Students { get; set; }
    public DbSet<Class> Classes { get; set; }
    public DbSet<Teacher> Teachers { get; set; }

    public MyDatabaseContext()
    {
        var folder = Environment.SpecialFolder.LocalApplicationData;
        var path = Environment.GetFolderPath(folder);
        DbPath = System.IO.Path.Join(path, "school.db");
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite($"Data Source={DbPath}");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Many-to-Many Students <-> Classes
        modelBuilder.Entity<Student>()
            .HasMany(s => s.Classes)
            .WithMany(c => c.Students);
    }
}
#endregion

internal class Program
{
    static void Main(string[] args)
    {
        using var db = new MyDatabaseContext();
        db.Database.EnsureCreated();

        // Clear DB on every run
        db.Students.RemoveRange(db.Students);
        db.Classes.RemoveRange(db.Classes);
        db.Teachers.RemoveRange(db.Teachers);
        db.SaveChanges();

        Console.WriteLine("Database cleared!");

        // 1f. Add some data
        var student1 = new Student { FirstName = "Alice", LastName = "Johnson" };
        var student2 = new Student { FirstName = "Bob", LastName = "Smith" };
        var student3 = new Student { FirstName = "Cathy", LastName = "Brown" };

        var class1 = new Class { Name = "Mathematics" };
        var class2 = new Class { Name = "Physics" };

        db.Students.AddRange(student1, student2, student3);
        db.Classes.AddRange(class1, class2);
        db.SaveChanges();

        PrintAll(db);

        // 2a. Add Teacher to a Class
        var mathClass = db.Classes.First(c => c.Name == "Mathematics");
        var teacher1 = new Teacher { FirstName = "John", LastName = "Doe" };
        mathClass.Teacher = teacher1;
        db.SaveChanges();

        Console.WriteLine("\nAfter assigning teacher to Mathematics:");
        PrintAll(db);

        // 2b. Add another Teacher + Class, then delete Teacher
        var teacher2 = new Teacher { FirstName = "Mary", LastName = "Poppins" };
        var class3 = new Class { Name = "Chemistry", Teacher = teacher2 };
        db.Classes.Add(class3);
        db.SaveChanges();

        Console.WriteLine("\nAfter adding Chemistry class with Mary Poppins:");
        PrintAll(db);

        db.Teachers.Remove(teacher2);
        db.SaveChanges();
        Console.WriteLine("\nAfter removing Mary Poppins (Chemistry teacher):");
        PrintAll(db);

        // 3. Teacher with many classes
        var teacherClasses = db.Teachers.Include(t => t.Classes).FirstOrDefault();
        if (teacherClasses != null)
        {
            Console.WriteLine($"\nTeacher {teacherClasses.FirstName} teaches:");
            foreach (var c in teacherClasses.Classes)
                Console.WriteLine($" - {c.Name}");
        }

        // 4. Many-to-Many Students <-> Classes
        var physicsClass = db.Classes.First(c => c.Name == "Physics");
        student1.Classes.Add(mathClass);
        student1.Classes.Add(physicsClass);
        student2.Classes.Add(physicsClass);
        db.SaveChanges();

        Console.WriteLine("\nAfter assigning students to classes:");
        foreach (var s in db.Students.Include(s => s.Classes))
        {
            Console.WriteLine($"{s.FirstName} is enrolled in: {string.Join(", ", s.Classes.Select(c => c.Name))}");
        }
    }

    static void PrintAll(MyDatabaseContext db)
    {
        Console.WriteLine("\n--- Students ---");
        foreach (var s in db.Students.ToList())
            Console.WriteLine(s);

        Console.WriteLine("\n--- Classes ---");
        foreach (var c in db.Classes.Include(c => c.Teacher).ToList())
            Console.WriteLine(c);

        Console.WriteLine("\n--- Teachers ---");
        foreach (var t in db.Teachers.ToList())
            Console.WriteLine(t);
    }
}
